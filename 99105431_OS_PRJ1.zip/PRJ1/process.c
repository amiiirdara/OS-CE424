#include "process.h"
#include "shell.h"
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <termios.h>
#include <fcntl.h>
#include <sys/stat.h>

#include "io.h"
#include "parse.h"
#include "process.h"

#include <string.h>

#include "shell.h"


/**
 * Executes the process p.
 * If the shell is in interactive mode and the process is a foreground process,
 * then p should take control of the terminal.
 */
void launchProcess(process* p)
{
    tok_t* inputPath = p->argv;
    tok_t* paths = getToks(getenv("PATH"));
    int count;
    for (count = 0; paths[count] != NULL; count++);
    int pathsLen = count;

    dup2(p->stdin, 0);
    dup2(p->stdout, 1);

    if (access(p->argv[0], F_OK) == 0)
    {
        execv(p->argv[0], &inputPath[0]);
        return;
    }

    char* path = (char*)malloc(1024 * sizeof(char));

    for (int i = 0; i < pathsLen; i++)
    {
        strcpy(path, paths[i]);
        strcat(path, "/");
        strcat(path, inputPath[0]);
        if (access(path, F_OK) == 0)
        {
            execv(path, &inputPath[0]);
            free(path);
            return;
        }
    }
    free(path);
}
