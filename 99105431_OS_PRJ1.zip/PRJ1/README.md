# Shell

Implementation of a shell using C that works with Persian commands
---
