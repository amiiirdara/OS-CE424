#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <errno.h>
#include <unistd.h>
#include <termios.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <dirent.h>


#define FALSE 0
#define TRUE 1
#define INPUT_STRING_SIZE 80
#define MAX_VARS 10 // Maximum number of variables


#include "io.h"
#include "parse.h"
#include "process.h"
#include "shell.h"

int cmd_quit(tok_t arg[])
{
    printf("Bye\n");
    exit(0);
    return 1;
}


int cmd_help(tok_t arg[]);
int cmd_pwd(tok_t arg[]);
int cmd_ls(tok_t arg[]);
int cmd_private_ls(tok_t arg[]);
int cmd_cd(tok_t arg[]);
int cmd_cat(tok_t arg[]);
int cmd_wait(tok_t arg[]);
int cmd_set_var(tok_t arg[]);
int cmd_get_var(tok_t arg[]);

int can_execute(const char* path);
int execute_command(char** args);


/* Command Lookup table */
typedef int cmd_fun_t(tok_t args[]); /* cmd functions take token array and return int */
typedef struct fun_desc
{
    cmd_fun_t* fun;
    char* cmd;
    char* doc;
} fun_desc_t;

fun_desc_t cmd_table[] = {
    {cmd_help, "?", "show this help menu"},
    {cmd_quit, "quit", "quit the command shell"},
    {cmd_pwd, "pwd", "show the current directory path"},
    {cmd_ls, "ls", "list the contents of a directory"},
    {cmd_private_ls, "private_ls", "list the contents of a directory with privacy"},
    {cmd_cd, "cd", "changes the current working dirctory of shell"},
    {cmd_cat, "cat", "display the content of a file"},
    {cmd_wait, "wait", "Wait until all the background processes are done"},
    {cmd_set_var, "set", "set a local variable"},
    {cmd_get_var, "get", "get the value of a local variable"},
};

typedef struct
{
    char name[INPUT_STRING_SIZE];
    char value[INPUT_STRING_SIZE];
} Variable;

Variable variables[MAX_VARS];
int variable_count = 0;

int cmd_set_var(tok_t arg[])
{
    if (arg[0] && arg[1] && variable_count < MAX_VARS)
    {
        strcpy(variables[variable_count].name, arg[0]);
        strcpy(variables[variable_count].value, arg[1]);
        variable_count++;
        printf("Variable set: %s = %s\n", arg[0], arg[1]);
    }
    else
    {
        printf("Error: Invalid arguments or variable limit reached.\n");
    }
    return 1;
}

int cmd_get_var(tok_t arg[])
{
    if (arg[0])
    {
        for (int i = 0; i < variable_count; i++)
        {
            if (strcmp(variables[i].name, arg[0]) == 0)
            {
                printf("%s\n", variables[i].value);
                return 1;
            }
        }
        printf("Variable not found: %s\n", arg[0]);
    }
    else
    {
        printf("Error: No variable name provided.\n");
    }
    return 1;
}

const char* get_variable_value(const char* name)
{
    for (int i = 0; i < variable_count; i++)
    {
        if (strcmp(variables[i].name, name) == 0)
        {
            return variables[i].value;
        }
    }
    return NULL; // Variable not found
}


// This function checks if a command can be executed
int can_execute(const char* path)
{
    struct stat st;
    return stat(path, &st) == 0 && st.st_mode & S_IXUSR;
}

int execute_command(char** args)
{
    int background = 0;
    int redirectIndex = -1;
    char* filename = NULL;

    // Check for background execution symbol '&' at the beginning
    if (args[0] != NULL && strcmp(args[0], "&") == 0)
    {
        background = 1;
        // Shift all arguments to the left to remove '&'
        for (int i = 0; args[i + 1] != NULL; i++)
        {
            args[i] = args[i + 1];
        }
        args[0] = NULL; // Clear the '&' argument to avoid confusion in execvp
    }

    for (int i = 0; args[i] != NULL; i++)
    {
        if (args[i][0] == '$')
        {
            const char* varValue = get_variable_value(args[i] + 1); // Skip the '$'
            if (varValue)
            {
                free(args[i]); // Free the original arg memory if it was dynamically allocated
                args[i] = strdup(varValue); // Replace the variable with its value
            }
            else
            {
                fprintf(stderr, "Variable %s not found\n", args[i]);
                return 1;
            }
        }
    }

    // Check for output redirection '>'
    for (int i = 0; args[i] != NULL; i++)
    {
        if (strcmp(args[i], ">") == 0)
        {
            if (args[i + 1] != NULL)
            {
                redirectIndex = i;
                filename = args[i + 1];
                break;
            }
            else
            {
                fprintf(stderr, "No file specified for redirection\n");
                return 1;
            }
        }
    }

    // Remove redirection symbol and filename from args if found
    if (redirectIndex != -1)
    {
        args[redirectIndex] = NULL; // Truncate the arguments list before '>'
    }

    pid_t pid = fork();
    if (pid == 0)
    {
        // Child process

        // Handle output redirection if '>' was detected
        if (redirectIndex != -1)
        {
            int fd = open(filename, O_WRONLY | O_CREAT | O_TRUNC, S_IRUSR | S_IWUSR);
            if (fd < 0)
            {
                perror("open");
                exit(EXIT_FAILURE);
            }
            if (dup2(fd, STDOUT_FILENO) < 0)
            {
                perror("dup2");
                exit(EXIT_FAILURE);
            }
            close(fd); // Close the file descriptor as it's no longer needed
        }

        // Execute the command
        if (execvp(args[0], args) == -1)
        {
            perror("execvp");
            exit(EXIT_FAILURE);
        }
    }
    else if (pid < 0)
    {
        // Error forking
        perror("fork");
    }
    else
    {
        // Parent process
        if (!background)
        {
            int status;
            waitpid(pid, &status, 0); // Wait for the command to complete if not in background
        }
        else
        {
            printf("Process %d running in background.\n", pid);
            // Optionally, add the background process to a list of background processes if you want to track them
        }
    }

    return 1;
}


int cmd_pwd(tok_t arg[])
{
    char cwd[1000];
    getcwd(cwd, sizeof(cwd));
    printf("Current working directory is: %s\n", cwd);
    return 1;
}

int cmd_ls(tok_t arg[])
{
    DIR* d;
    struct dirent* dir;
    char* dirName = arg[0] ? arg[0] : "."; // Use the current directory if no argument is provided
    d = opendir(dirName);
    if (d)
    {
        while ((dir = readdir(d)) != NULL)
        {
            // You might want to filter out "." and ".." entries
            if (strcmp(dir->d_name, ".") != 0 && strcmp(dir->d_name, "..") != 0)
            {
                printf("%s\n", dir->d_name);
            }
        }
        closedir(d);
    }
    else
    {
        perror("ls");
    }
    return 1;
}

int cmd_private_ls(tok_t arg[])
{
    DIR* d;
    struct dirent* dir;
    char* dirName = arg[0] ? arg[0] : ".";
    char modifiedName[256]; // Assuming file names won't exceed this length
    d = opendir(dirName);
    if (d)
    {
        while ((dir = readdir(d)) != NULL)
        {
            if (strcmp(dir->d_name, ".") != 0 && strcmp(dir->d_name, "..") != 0)
            {
                strncpy(modifiedName, dir->d_name, sizeof(modifiedName));
                int nameLen = strlen(modifiedName);
                // Replace last 6 characters with '_' if the name is long enough
                if (nameLen > 6)
                {
                    for (int i = nameLen - 6; i < nameLen; i++)
                    {
                        modifiedName[i] = '_';
                    }
                }
                else
                {
                    // If the name is shorter than 6 characters, replace the entire name
                    for (int i = 0; i < nameLen; i++)
                    {
                        modifiedName[i] = '_';
                    }
                }
                modifiedName[nameLen] = '\0'; // Null-terminate the modified name
                printf("%s\n", modifiedName);
            }
        }
        closedir(d);
    }
    else
    {
        perror("private_ls");
    }
    return 1;
}


int cmd_cd(tok_t arg[])
{
    if (chdir(arg[0]) != 0)
    {
        printf("an error occurred\n");
    }
    return 1;
}

int cmd_cat(tok_t arg[])
{
    if (arg[0] == NULL)
    {
        printf("cat: Please specify a file.\n");
        return 1;
    }
    FILE* file = fopen(arg[0], "r");
    if (file == NULL)
    {
        perror("cat");
        return 1;
    }
    char line[1024]; // Adjust size as needed
    while (fgets(line, sizeof(line), file) != NULL)
    {
        printf("%s", line);
    }
    fclose(file);
    return 1;
}


int cmd_wait(tok_t arg[])
{
    int* status;
    while (waitpid(-1, status, 0) > 0) { ; }
    return 1;
}

int cmd_help(tok_t arg[])
{
    int i;
    for (i = 0; i < (sizeof(cmd_table) / sizeof(fun_desc_t)); i++)
    {
        printf("%s - %s\n", cmd_table[i].cmd, cmd_table[i].doc);
    }
    return 1;
}

int lookup(char cmd[])
{
    int i;
    for (i = 0; i < (sizeof(cmd_table) / sizeof(fun_desc_t)); i++)
    {
        if (cmd && (strcmp(cmd_table[i].cmd, cmd) == 0)) return i;
    }
    return -1;
}

void init_shell()
{
    /* Check if we are running interactively */
    shell_terminal = STDIN_FILENO;

    /** Note that we cannot take control of the terminal if the shell is not interactive */
    shell_is_interactive = isatty(shell_terminal);

    if (shell_is_interactive)
    {
        /* force into foreground */
        while (tcgetpgrp(shell_terminal) != (shell_pgid = getpgrp()))
            kill(-shell_pgid, SIGTTIN);

        shell_pgid = getpid();
        /* Put shell in its own process group */
        if (setpgid(shell_pgid, shell_pgid) < 0)
        {
            perror("Couldn't put the shell in its own process group");
            exit(1);
        }

        /* Take control of the terminal */
        tcsetpgrp(shell_terminal, shell_pgid);
        tcgetattr(shell_terminal, &shell_tmodes);

        signal(SIGINT, SIG_IGN);
        signal(SIGQUIT, SIG_IGN);
        signal(SIGTSTP, SIG_IGN);
        signal(SIGTTIN, SIG_IGN);
        signal(SIGTTOU, SIG_IGN);
    }
}

/**
 * Add a process to our process list
 */
void add_process(process* p)
{
    process* new_process = (process*)malloc(sizeof(process));
    if (first_process == NULL)
    {
        first_process = new_process;
        return;
    }

    process* current = first_process;
    while (current->next != NULL)
    {
        current = current->next;
    }

    current->next = new_process;
    new_process->prev = current;
}

/**
 * Creates a process given the inputString from stdin
 */
process* create_process(tok_t* inputString)
{
    tok_t* t = inputString;
    int count;
    for (count = 0; t[count] != NULL; count++);
    process* p = (process*)malloc(sizeof(process));
    p->argv = inputString;
    p->argc = count;
    p->completed = 0;
    p->stopped = 0;
    p->status = 0;

    p->stderr = STDERR_FILENO;

    int redirectIndex;
    if (p->argv && (redirectIndex = isDirectTok(p->argv, "<")) > 0)
    {
        if (p->argv[redirectIndex + 1] == NULL)
            return;
        int file = open(p->argv[redirectIndex + 1], O_RDONLY);
        if (file >= 0)
            p->stdin = file;
        int i;
        for (i = redirectIndex; i < p->argc; i++)
            p->argv[i] = NULL;
    }
    if (p->argv && (redirectIndex = isDirectTok(p->argv, ">")) > 0)
    {
        if (p->argv[redirectIndex + 1] == NULL)
            return;
        int file = open(p->argv[redirectIndex + 1], O_CREAT | O_TRUNC | O_WRONLY,
                        S_IRUSR | S_IWUSR | S_IROTH | S_IWOTH);
        if (file >= 0)
            p->stdout = file;
        int i;
        for (i = redirectIndex; i < p->argc; i++)
            p->argv[i] = NULL;
    }

    p->argc = count;

    p->prev = NULL;
    p->next = NULL;
    if (p->argv && strcmp(p->argv[p->argc - 1], "&") == 0)
    {
        p->background = 1;
        p->argv[--p->argc] = NULL;
    }

    return p;
}


int shell(int argc, char* argv[])
{
    char* s = malloc(INPUT_STRING_SIZE + 1); /* user input string */
    tok_t* t; /* tokens parsed from input */
    int lineNum = 0;
    int fundex = -1;
    pid_t pid = getpid(); /* get current processes PID */
    pid_t ppid = getppid(); /* get parents PID */
    pid_t cpid, tcpid, cpgid;

    init_shell();


    lineNum = 0;
    while ((s = freadln(stdin)))
    {
        t = getToks(s); /* break the line into tokens */
        fundex = lookup(t[0]); /* Is first token a shell literal */
        if (fundex >= 0) cmd_table[fundex].fun(&t[1]);
        else
        {
            process* process = create_process(t);
            add_process(process);


            if (fork() == 0)
            {
                signal(SIGINT, SIG_DFL);
                signal(SIGQUIT, SIG_DFL);
                signal(SIGTSTP, SIG_DFL);
                signal(SIGTTIN, SIG_DFL);
                signal(SIGTTOU, SIG_DFL);

                process->pid = getpid();
                launchProcess(process);
            }
            else
            {
                printf("%d\n", getpid());
            }
        }
    }
    return 0;
}
